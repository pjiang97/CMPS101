DROP SCHEMA Lab1 CASCADE;
CREATE SCHEMA Lab1;

SELECT timeofday();

CREATE TABLE ChirpUsers(
	userID		integer PRIMARY KEY,
	userPassword	char(8),
	userName	varChar(30),
	joinDate	date,
	address		varChar(30),
	education	char(1),
	income		decimal, 
	spouseID	integer,
	active		boolean
);

CREATE TABLE ChirpPosts(
	posterID	integer,
	postNum		integer,
	thePost		varChar(44),
	censored	boolean,
	postDate	date,
	PRIMARY KEY (posterID, postNum)
);

CREATE TABLE ChirpFollowers(
	userID		integer,
	followerID	integer,
	followStartDate	date,
	PRIMARY KEY (userID, followerID)
);

CREATE TABLE ChirpReads(
	posterID 	integer,
	postNum		integer,
	postReader	integer,
	timesRead	integer,
	latestReadDate	date,
	PRIMARY KEY (posterID, postNum, postReader)
);
